#include "pico/stdlib.h"
#include <stdio.h>
#include <stdbool.h>
#include "buttons.h"

void wave_output(WaveType wave) {
    switch(wave) {
        case WAVE_OFF:
            printf("Wave OFF\n");
            break;
        case WAVE_SINE:
            printf("Wave SINE\n");
            break;
        case WAVE_SAWTOOTH:
            printf("Wave SAW\n");
            break;
        case WAVE_TRIANGLE:
            printf("Wave TRIANGLE\n");
            break;
        case WAVE_SQUARE:
            printf("Wave SQUARE\n");
            break;
        default:
            break;
    }
}

void init_gpio()
{
    gpio_init(BUTTON_MODE);
    gpio_set_dir(BUTTON_MODE, GPIO_IN);
    gpio_pull_down(BUTTON_MODE);

    gpio_init(BUTTON_CAPTURE);
    gpio_set_dir(BUTTON_CAPTURE, GPIO_IN);
    gpio_pull_down(BUTTON_CAPTURE);

    gpio_init(X_CLK);
    gpio_set_dir(X_CLK, GPIO_IN);
    gpio_pull_up(X_CLK);

    gpio_init(X_DT);
    gpio_set_dir(X_DT, GPIO_IN);
    gpio_pull_up(X_DT);

    gpio_init(X_SW);
    gpio_set_dir(X_SW, GPIO_IN);
    gpio_pull_up(X_SW);

    gpio_init(Y_CLK);
    gpio_set_dir(Y_CLK, GPIO_IN);
    gpio_pull_up(Y_CLK);

    gpio_init(Y_DT);
    gpio_set_dir(Y_DT, GPIO_IN);
    gpio_pull_up(Y_DT);

    gpio_init(Y_SW);
    gpio_set_dir(Y_SW, GPIO_IN);
    gpio_pull_up(Y_SW);

    printf("GPIO Initialized\n");
}

volatile int x_encoder_steps = 0;
volatile int y_encoder_steps = 0;

int x_mode = 0;  // 0 = time scale, 1 = time shift, 2 = wave frequency control
int y_mode = 0;  // 0 = voltage scale, 1 = voltage shift, 2 = wave amplitude control
bool x_mode_changed = false;
bool y_mode_changed = false;

float x_offset = 0;
float y_offset = 0;

extern int volts_per_div;
extern int time_per_div;
extern bool grid_dirty;

extern bool pause;
WaveType current_wave = WAVE_OFF;
bool wave_type_changed = false;

// Wave generator control variables
float wave_frequency = 20.0f;  // Start at 100Hz
float wave_amplitude = 1.65f;   // Start at 1.65V

void gpio_callback(uint gpio, uint32_t events)
{
    if (gpio == X_CLK){
        int clk = gpio_get(X_CLK);
        int dt  = gpio_get(X_DT);
        x_encoder_steps += (dt != clk) ? 1 : -1;
        x_encoder_steps %= 10;
    }
    else if (gpio == Y_CLK){
        int clk = gpio_get(Y_CLK);
        int dt  = gpio_get(Y_DT);
        y_encoder_steps += (dt != clk) ? 1 : -1;
    }
    else if (gpio == BUTTON_CAPTURE) {
        pause = !pause;
        printf("PAUSE = %d\n", pause);
    }
    else if (gpio == BUTTON_MODE){
        current_wave = (current_wave + 1) % WAVE_COUNT;
        wave_output(current_wave);
        wave_type_changed = true;
        
        wavegen_set_type(current_wave);
        
        if (current_wave == WAVE_OFF) {
            wavegen_enable(false);
            printf("Wave generator DISABLED\n");
        } else {
            wavegen_set_frequency(wave_frequency);
            wavegen_set_amplitude(wave_amplitude);
            wavegen_enable(true);
            printf("Wave generator ENABLED: Type=%d, Freq=%.1fHz, Amp=%.2fV\n", 
                   current_wave, wave_frequency, wave_amplitude);
        }
    }
}

void init_encoders()
{
    gpio_init(X_CLK);
    gpio_set_dir(X_CLK, GPIO_IN);
    gpio_pull_up(X_CLK);

    gpio_init(X_DT);
    gpio_set_dir(X_DT, GPIO_IN);
    gpio_pull_up(X_DT);

    gpio_init(Y_CLK);
    gpio_set_dir(Y_CLK, GPIO_IN);
    gpio_pull_up(Y_CLK);

    gpio_init(Y_DT);
    gpio_set_dir(Y_DT, GPIO_IN);
    gpio_pull_up(Y_DT);

    gpio_set_irq_enabled_with_callback(
        X_CLK,
        GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
        true,
        &gpio_callback
    );

    gpio_set_irq_enabled(
        Y_CLK,
        GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
        true
    );
    
    gpio_set_irq_enabled(
        BUTTON_CAPTURE,
        GPIO_IRQ_EDGE_RISE,
        true
    );
    
    gpio_set_irq_enabled(
        BUTTON_MODE,
        GPIO_IRQ_EDGE_RISE,
        true
    );
}

bool last_x_button = false;
bool last_y_button = false;

bool check_button(int pin, bool *last_state)
{
    bool s = gpio_get(pin);
    if (s && !(*last_state))
    {
        sleep_ms(20);
        *last_state = true;
        return true;
    }
    if (!s)
        *last_state = false;

    return false;
}

void controls()
{
    // Handle X Button - cycle through modes (Scale, Shift, Wave Freq)
    if (check_button(X_SW, &last_x_button))
    {
        x_mode = (x_mode + 1) % 3;  // 0=scale, 1=shift, 2=wave freq
        x_mode_changed = true;
        
        if (x_mode == 0) {
            printf("X Mode: Scale (Time/div)\n");
        } else if (x_mode == 1) {
            printf("X Mode: Shift\n");
        } else {
            printf("X Mode: Wave Frequency Control\n");
        }
    }

    // Handle Y Button - cycle through modes (Scale, Shift, Wave Amp)
    if (check_button(Y_SW, &last_y_button))
    {
        y_mode = (y_mode + 1) % 3;  // 0=scale, 1=shift, 2=wave amp
        y_mode_changed = true;
        
        if (y_mode == 0) {
            printf("Y Mode: Scale (Volts/div)\n");
        } else if (y_mode == 1) {
            printf("Y Mode: Shift\n");
        } else {
            printf("Y Mode: Wave Amplitude Control\n");
        }
    }

    // X encoder steps
    int steps_x = x_encoder_steps;
    x_encoder_steps = 0;
    int factor = 1;
    
    if (steps_x != 0)
    {
        if (x_mode == 2) // WAVE FREQUENCY CONTROL
        {
            // Adjust wave frequency
            if (wave_frequency < 100.0f) {
                wave_frequency += steps_x * 10.0f;  // 10Hz steps below 100Hz
            } else if (wave_frequency < 1000.0f) {
                wave_frequency += steps_x * 50.0f;  // 50Hz steps below 1kHz
            } else {
                wave_frequency += steps_x * 100.0f; // 100Hz steps above 1kHz
            }
            
            // Clamp frequency
            if (wave_frequency < 10.0f) wave_frequency = 10.0f;
            if (wave_frequency > 5000.0f) wave_frequency = 5000.0f;
            
            // Update wave generator if enabled
            if (current_wave != WAVE_OFF) {
                wavegen_set_frequency(wave_frequency);
            }
            
            printf("Wave Frequency = %.1f Hz\n", wave_frequency);
        }
        else if (x_mode == 1) // SHIFT
        {
            x_offset += steps_x * 0.3f;
            printf("X Offset = %.2f\n", x_offset); 
        }
        else // SCALE (time)
        {
            if (time_per_div>=1000000){ 
                factor = 1000000;
            }
            else if (time_per_div >= 100000 ){ 
                factor = 100000;
            }
            else if (time_per_div >= 10000 ){ 
                factor = 10000;
            }
            else if (time_per_div >= 1000 ){ 
                factor = 1000;
            }
            else if (time_per_div >= 100){ 
                factor = 100;
            }
            else if (time_per_div >= 10){
                factor = 10;
            }
            else {
                factor = 1;
            }

            time_per_div += factor*steps_x;
            if (time_per_div<1){
                time_per_div =1;
            }
            time_per_div %= 10000001;
            
            if (time_per_div>1000000){ 
                printf("Time/div = %ds\n", time_per_div/1000000);
            }
            else if (time_per_div > 1000){ 
                printf("Time/div = %dms\n", time_per_div/1000);
            }
            else {
                printf("Time/div = %dus\n", time_per_div);
            }
        }
        grid_dirty = true;
    }

    // Y encoder steps
    int steps_y = y_encoder_steps;
    y_encoder_steps = 0;

    if (steps_y != 0)
    {
        grid_dirty = true;
        
        if (y_mode == 2) // WAVE AMPLITUDE CONTROL
        {
            // Adjust wave amplitude in 0.1V steps
            wave_amplitude += steps_y * 0.1f;
            
            // Clamp amplitude
            if (wave_amplitude < 0.1f) wave_amplitude = 0.1f;
            if (wave_amplitude > 3.0f) wave_amplitude = 3.0f;
            
            // Update wave generator if enabled
            if (current_wave != WAVE_OFF) {
                wavegen_set_amplitude(wave_amplitude);
            }
            
            printf("Wave Amplitude = %.2f V\n", wave_amplitude);
        }
        else if (y_mode == 1) // SHIFT
        {
            y_offset = y_offset + steps_y * volts_per_div;
            printf("Y Offset = %.2f\n", y_offset);
        }
        else // SCALE (voltage)
        {
            volts_per_div += steps_y;
            volts_per_div %= 11;
            if (volts_per_div < 1) volts_per_div = 1;
            printf("Volts/div = %dV\n", volts_per_div);
        }
    }
}