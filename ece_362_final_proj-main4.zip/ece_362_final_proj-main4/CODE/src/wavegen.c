// All wavegen code here
#include "wavegen.h"
#include "hardware/pwm.h"
#include <math.h>

// Configuration
WaveGenConfig wavegen_config = {
    .type = WAVE_OFF,
    .frequency = 50.0f,  // Default frequency: 1 kHz
    .amplitude = 1.65f,    // Default amplitude: 1.65V (centered at 1.65V for 0-3.3V range)
    .enabled = false       // Initially disabled
};

// Wavetable parameters
#define N 256              // Number of samples in wavetable
#define RATE 20000         // Sample rate in Hz (20 kHz)

// Static variables
static uint wavegen_pin = 0;           // GPIO pin used for PWM output
static uint wavegen_slice = 0;         // PWM slice index associated with the pin
static uint wavegen_chan = 0;          // PWM channel (A/B) for that pin
static short int wavetable[N];         // Wavetable storage
static volatile uint32_t offset0 = 0;  // Phase accumulator (Q16 fixed-point)
static volatile uint32_t step0 = 0;    // Phase increment (Q16 fixed-point)

// Constants
#define WAVEGEN_MAX_VOLT 3.3f  // Max reference voltage
#define MID_VALUE 16384.0f     // Midpoint sample value (for 16-bit)
#define BASE_AMP 16383.0f      // Base amplitude used for normalization

// Clamp a float value x into the range [lo, hi]
static inline float clampf(float x, float lo, float hi) {
    if (x < lo) 
        return lo;
    if (x > hi) 
        return hi;
    return x;
}

// Set the frequency for the waveform generator
static void set_freq(int channel, float freq) {
    // Calculate phase increment for the given frequency
    // step0 is in Q16 fixed-point format (16.16)
    // step0 = (freq * N * 65536) / RATE
    if (freq <= 0.0f) {
        step0 = 0;
    } else {
        step0 = (uint32_t)((freq * (float)N * 65536.0f) / (float)RATE);
    }
}

// Get sample value for oscilloscope display (not for PWM)
// This is needed because the oscilloscope can't read the PWM directly
float wavegen_get_sample(float t) {
    if (!wavegen_config.enabled)
        return 0.0f;

    float amplitude = wavegen_config.amplitude;
    float freq = wavegen_config.frequency;
    float phase = freq * t;

    switch (wavegen_config.type) {
        case WAVE_SINE:
            return amplitude * sinf(2.0f * 3.14159265 * phase);

        case WAVE_SQUARE:
            return (sinf(2.0f * 3.14159265 * phase) > 0 ? amplitude : -amplitude);

        case WAVE_SAWTOOTH:
            return amplitude * (2.0f * (phase - floorf(phase + 0.5f)));

        case WAVE_TRIANGLE:
            return amplitude * (2.0f * fabsf(2.0f * (phase - floorf(phase + 0.5f))) - 1.0f);

        default:
            return 0.0f;
    }
}

// Fill the wavetable with the specified waveform type and amplitude
static void wavegen_fill_wavetable(WaveType type, float amp_volt) {
    float norm_amp = clampf(amp_volt / WAVEGEN_MAX_VOLT, 0.0f, 1.0f);
    float amp = BASE_AMP * norm_amp;

    // If waveform is off, or amp is zero/non-positive, output a flat 0 signal
    if (type == WAVE_OFF || amp_volt <= 0.0f) {
        for (int i = 0; i < N; ++i) {
            wavetable[i] = 0; // Zero out all samples
        }
        return; 
    }

    // Generate one period of the waveform with N samples
    for (int i = 0; i < N; ++i) {
        float t = (float)i / (float)N;
        float s = 0.0f;

        // Choose waveform shape
        switch (type) {
            case WAVE_SINE:
                s = sinf(2.0f * 3.14159265 * t);
                break;

            case WAVE_SAWTOOTH:
                s = 2.0f * t - 1.0f;
                break;

            case WAVE_TRIANGLE:
                if (t < 0.25f)
                    s = 4.0f * t;
                else if (t < 0.75f)
                    s = 2.0f - 4.0f * t;
                else
                    s = 4.0f * t - 4.0f;
                break;

            case WAVE_SQUARE:
                s = (i < N/2) ? 1.0f : -1.0f;
                break;

            default:
                s = 0.0f;
        }

        // Convert normalized sample s (-1~1) to table value around mid_value
        float v = MID_VALUE + amp * s;
        if (v < 0.0f)
            v = 0.0f;
        if (v > 32767.0f)
            v = 32767.0f;
        
        wavetable[i] = (short int)v;
    }
}

// PWM interrupt handler
// Called whenever the PWM counter wraps, to update the output sample
static void wavegen_pwm_irq(void) {
    pwm_clear_irq(wavegen_slice);

    offset0 += step0;
    if (offset0 >= (N << 16)) {
        offset0 -= (N << 16);
    }

    // Use upper bits of offset0 as the wavetable index (Q16 -> integer index)
    int samp = wavetable[offset0 >> 16];

    // Get the current PWM period (= top + 1)
    int period = (int)pwm_hw->slice[wavegen_slice].top + 1;

    // Scale the 16-bit sample to the PWM resolution
    int level = (samp * period) >> 16;

    if (level < 0) 
        level = 0;
    if (level > period)
        level = period;

    pwm_set_chan_level(wavegen_slice, wavegen_chan, level);
}

// Initialize the wave generator on a specific GPIO pin
void wavegen_init(uint32_t pwm_pin) {
    wavegen_pin = pwm_pin;

    gpio_set_function(wavegen_pin, GPIO_FUNC_PWM);
    wavegen_slice = pwm_gpio_to_slice_num(wavegen_pin);
    wavegen_chan = pwm_gpio_to_channel(wavegen_pin);

    pwm_set_clkdiv(wavegen_slice, 150.0f);

    int period = (1000000 / RATE) - 1;
    pwm_set_wrap(wavegen_slice, period);
    pwm_set_chan_level(wavegen_slice, wavegen_chan, 0);

    wavegen_fill_wavetable(WAVE_SINE, wavegen_config.amplitude);
    set_freq(0, wavegen_config.frequency);

    pwm_clear_irq(wavegen_slice);
    pwm_set_irq_enabled(wavegen_slice, true);
    irq_set_exclusive_handler(PWM_IRQ_WRAP, wavegen_pwm_irq);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    pwm_set_enabled(wavegen_slice, true);
}

// Change the waveform type
void wavegen_set_type(WaveType type) {
    if (type < 0 || type >= WAVE_COUNT) 
        return;
    
    wavegen_config.type = type;
    wavegen_fill_wavetable(wavegen_config.type, wavegen_config.amplitude);
}

// Change the waveform frequency
void wavegen_set_frequency(float freq_hz) {
    if (freq_hz < 0.0f) 
        freq_hz = 0.0f;
    
    wavegen_config.frequency = freq_hz;

    if (wavegen_config.enabled && wavegen_config.frequency > 0.0f) {
        set_freq(0, wavegen_config.frequency);
    } else {
        set_freq(0, 0.0f);
    }
}

// Change the waveform amplitude in volts
void wavegen_set_amplitude(float amp_volt) {
    wavegen_config.amplitude = clampf(amp_volt, 0.0f, WAVEGEN_MAX_VOLT);
    wavegen_fill_wavetable(wavegen_config.type, wavegen_config.amplitude);
}

// Enable or disable the wave generator
void wavegen_enable(bool enable) {
    wavegen_config.enabled = enable;

    if (!enable) {
        set_freq(0, 0.0f);
        pwm_set_chan_level(wavegen_slice, wavegen_chan, 0);
    } else {
        set_freq(0, wavegen_config.frequency);
    }
}

// Update function (currently unused, but available for future features)
void wavegen_update(void) {
    // Reserved for future use
}