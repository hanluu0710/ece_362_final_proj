#ifndef BUTTONS_H
#define BUTTONS_H

#include <stdbool.h>
#include "wavegen.h"

// Button pins
#define BUTTON_MODE 3       // Wave type change button
#define BUTTON_CAPTURE 4    // Pause/capture button

// X encoder pins
#define X_CLK 5
#define X_DT 6
#define X_SW 7

// Y encoder pins - CHANGED TO AVOID GPIO 3 CONFLICT
#define Y_CLK 8
#define Y_DT 9
#define Y_SW 10

// Function declarations
void init_gpio(void);
void controls(void);
void init_encoders(void);

bool check_mode_button(void);
bool check_capture_button(void);
int read_encoder_x(void);
int read_encoder_y(void);
bool check_x_button(void);
bool check_y_button(void);

extern bool x_mode_changed;
extern bool y_mode_changed;
extern float x_offset;
extern float y_offset;
extern int x_mode;
extern int y_mode;
extern WaveType current_wave;
extern bool wave_type_changed;

#endif